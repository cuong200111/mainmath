import React from "react";
import Header from "../../components/header";
import Footer from "../../components/footer";
import Container from "./container";
import BreadCrumb from "../../components/brekCrumb";

const Home = () => {
  return (
    <div className="homePage">
      {" "}
      {/* <Header /> */}

      <Container />
      {/* <Footer /> */}
    </div>
  );
};

export default Home;
