import React from "react";
import { Route, Routes, BrowserRouter } from "react-router-dom";
import router from "./routes";
import Layout from "./page/Layout";
const App = () => {
  return (
 <Layout />
  );
};

export default App;
